CREATE TABLE `cimahiwall_revslider_static_slides` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `slider_id` int(9) NOT NULL,  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,  `layers` text COLLATE utf8mb4_unicode_ci NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `cimahiwall_revslider_static_slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `cimahiwall_revslider_static_slides` ENABLE KEYS */;
