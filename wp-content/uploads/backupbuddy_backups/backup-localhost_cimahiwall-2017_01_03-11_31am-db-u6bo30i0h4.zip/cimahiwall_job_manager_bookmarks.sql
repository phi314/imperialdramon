CREATE TABLE `cimahiwall_job_manager_bookmarks` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `user_id` bigint(20) NOT NULL,  `post_id` bigint(20) NOT NULL,  `bookmark_note` longtext COLLATE utf8mb4_unicode_ci,  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `cimahiwall_job_manager_bookmarks` DISABLE KEYS */;
INSERT INTO `cimahiwall_job_manager_bookmarks` VALUES('1', '1', '128', '', '2017-01-03 10:59:09');
/*!40000 ALTER TABLE `cimahiwall_job_manager_bookmarks` ENABLE KEYS */;
