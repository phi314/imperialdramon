CREATE TABLE `cimahiwall_megamenu_widgets` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(250) NOT NULL,  `type` varchar(255) NOT NULL,  `params` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `cimahiwall_megamenu_widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `cimahiwall_megamenu_widgets` ENABLE KEYS */;
